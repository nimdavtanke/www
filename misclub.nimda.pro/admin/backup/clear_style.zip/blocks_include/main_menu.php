<?
//$id,$cat_id,$level_start,$level_end,$level_now, $show_levels,$style,$menu
$main_menu = create_menu (1,0,1,5,1,4,"main_menu","");

?>