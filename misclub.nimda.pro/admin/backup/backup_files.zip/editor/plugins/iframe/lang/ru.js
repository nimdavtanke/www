﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ru', {
	border: 'Показать границы фрейма',
	noUrl: 'Пожалуйста, введите ссылку фрейма',
	scrolling: 'Отображать полосы прокрутки',
	title: 'Свойства iFrame',
	toolbar: 'iFrame'
});
