<?php
echo exec('mysql --user=dbuser --password=delpHI01work --host=localhost srv42620_pmis > dump3.sql');
?>
