<?php
echo "123123<br />";
error_reporting(E_ALL);
echo "3222<br />":
require("../functions/main.func.php");
    echo "555";
?>