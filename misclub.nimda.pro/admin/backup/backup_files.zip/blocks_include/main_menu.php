<?
//$id,$cat_id,$level_start,$level_end,$level_now, $show_levels,$style,$menu
$main_menu = "<ul class='main_menu'>" . create_menu (1,0,1,1,1,1,"main_menu","") . "</ul>";

?>